<%@ page contentType="text/html;charset=UTF-8" language="java" %>
<%
    // Redirect all errors back to the SwaggerUI page to display the available APIs
    response.sendRedirect(request.getContextPath() + "/swaggerui/?url=/loadsuite/web/api/catalog/openapi");
%>