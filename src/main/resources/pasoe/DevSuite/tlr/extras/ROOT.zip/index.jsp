<%@ page language="java"
         contentType="text/html;charset=UTF-8"
         pageEncoding="UTF-8"
         session="false"
         errorPage="/WEB-INF/jsp/errorPage.jsp"%>
<%
  request.getRequestDispatcher("/swaggerui/?url=/devsuite/web/api/catalog/openapi").forward(request, response);
%>
