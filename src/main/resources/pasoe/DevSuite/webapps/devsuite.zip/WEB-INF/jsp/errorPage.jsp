<%@ page language="java"
         contentType="text/html;charset=UTF-8"
         pageEncoding="UTF-8"
         session="false"
         isErrorPage="true"
         trimDirectiveWhitespaces="true"
         import="java.io.*"
         import="java.util.*"
         import="java.system.*" %>
<%@ taglib prefix="sec" uri="/WEB-INF/security.tld" %>
<%
    String accept = String.valueOf(request.getHeader("Accept")).toLowerCase(java.util.Locale.ROOT);
    String xrw = String.valueOf(request.getHeader("X-Requested-With"));
    String format = String.valueOf(request.getParameter("format"));

    String requestId = String.valueOf(request.getAttribute("OEReq.requestId") == null ? "" : request.getAttribute("OEReq.requestId"));
    requestId = requestId.replace("\r", "").replace("\n", "");
    if (!requestId.isEmpty()) {
        response.setHeader("App-Request-ID", requestId);
    }

    boolean wantsJson = accept.contains("application/json")
                     || accept.contains("+json")
                     || "XMLHttpRequest".equalsIgnoreCase(xrw)
                     || "json".equalsIgnoreCase(format);

    if (wantsJson) {
        request.setAttribute("psc.as.attr.errorFormat", "json");
        response.setContentType("application/json;charset=UTF-8");
%>
<%@  include file="errorJSONBody.jsp" %>
<%
    } else {
        request.setAttribute("psc.as.attr.errorFormat", "html");
%>
<html>
<head>
<title>Progress Application Server Error</title>
<link rel="stylesheet" type="text/css" href="<%= request.getContextPath()%>/static/commonStyle.css" media="screen" />
<meta http-equiv="Cache-Control" content="no-store" />
</head>
<body>
<%@  include file="errorPageHeader.jsp" %>
<%@  include file="errorPageBody.jsp" %>
<%@  include file="errorPageFooter.jsp" %>
</body>
</html>
<%
    }
%>

